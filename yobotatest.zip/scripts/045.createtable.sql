USE SCRIPTS;
CREATE TABLE testTable6
(
  Id Integer(10),
  Script varchar(25)
);
