USE SCRIPTS;
CREATE TABLE testTable5
(
  Id Integer(10),
  Script varchar(25)
);
