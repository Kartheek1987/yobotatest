USE SCRIPTS;
CREATE TABLE testTable4
(
  Id Integer(10),
  Script varchar(25)
);
