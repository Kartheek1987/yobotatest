USE SCRIPTS;
CREATE TABLE testTable7
(
  Id Integer(10),
  Script varchar(25)
);
